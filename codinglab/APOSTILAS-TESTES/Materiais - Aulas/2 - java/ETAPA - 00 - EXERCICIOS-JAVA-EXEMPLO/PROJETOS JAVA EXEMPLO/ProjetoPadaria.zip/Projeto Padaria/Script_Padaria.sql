
CREATE TABLE padaria.categoria (
                cat_codigo INT(10) NOT NULL,
                descricao VARCHAR(60) NOT NULL,
                PRIMARY KEY (CAT_CODIGO)
);



CREATE TABLE padaria.produto (
                pro_codigo INT(10) NOT NULL,
                valorunitario NUMERIC(10,2) NOT NULL,
                descricao VARCHAR(100) NOT NULL,
                cat_codigo INT(10) NOT NULL,
                PRIMARY KEY (PRO_CODIGO)
);



CREATE TABLE padaria.estado (
                est_sigla VARCHAR(2) NOT NULL,
                nome VARCHAR(120) NOT NULL,
                PRIMARY KEY (EST_SIGLA)
);


CREATE TABLE padaria.cidade (
                cid_codigo INT(10) NOT NULL,
                nome VARCHAR(120) NOT NULL,
                est_sigla VARCHAR(2) NOT NULL,
                PRIMARY KEY (CID_CODIGO)
);


CREATE TABLE padaria.cliente (
                cli_codigo INT(10) NOT NULL,
                nome VARCHAR(100) NOT NULL,
                pai VARCHAR(100),
                mae VARCHAR(100),
                bairro VARCHAR(60),
                datanascimento DATE,
                numero INT(10),
                email VARCHAR(120),
                endereco VARCHAR(120),
                sexo VARCHAR(1),
                cid_codigo INT(10),
                PRIMARY KEY (CLI_CODIGO)
);



CREATE TABLE padaria.venda (
                ven_numero INT(10) NOT NULL,
                datavenda DATE NOT NULL,
                valortotal NUMERIC(10,2),
                cli_codigo INT(10) NOT NULL,
                PRIMARY KEY (VEN_NUMERO)
);



CREATE TABLE padaria.item (
                pro_codigo INT(10) NOT NULL,
                ven_numero INT(10) NOT NULL,
                quantidade INT(10) NOT NULL,
                PRIMARY KEY (PRO_CODIGO, VEN_NUMERO)
);



CREATE TABLE padaria.telefone (
                tel_sequencia INT(10) NOT NULL,
                cli_codigo INT(10) NOT NULL,
                numero VARCHAR(16) NOT NULL,
                tipo VARCHAR(1) NOT NULL,
                PRIMARY KEY (TEL_SEQUENCIA, CLI_CODIGO)
);



ALTER TABLE padaria.produto ADD CONSTRAINT categoria_produto_fk
FOREIGN KEY (cat_codigo)
REFERENCES padaria.categoria (cat_codigo)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE padaria.item ADD CONSTRAINT produto_item_fk
FOREIGN KEY (pro_codigo)
REFERENCES padaria.produto (pro_codigo)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE padaria.cidade ADD CONSTRAINT estado_cidade_fk
FOREIGN KEY (est_sigla)
REFERENCES padaria.estado (est_sigla)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE padaria.cliente ADD CONSTRAINT cidade_aluno_fk
FOREIGN KEY (cid_codigo)
REFERENCES padaria.cidade (cid_codigo)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE padaria.telefone ADD CONSTRAINT aluno_telefone_fk
FOREIGN KEY (cli_codigo)
REFERENCES padaria.cliente (cli_codigo)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE padaria.venda ADD CONSTRAINT cliente_venda_fk
FOREIGN KEY (cli_codigo)
REFERENCES padaria.cliente (cli_codigo)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE padaria.item ADD CONSTRAINT venda_item_fk
FOREIGN KEY (ven_numero)
REFERENCES padaria.venda (ven_numero)
ON DELETE NO ACTION
ON UPDATE NO ACTION;
